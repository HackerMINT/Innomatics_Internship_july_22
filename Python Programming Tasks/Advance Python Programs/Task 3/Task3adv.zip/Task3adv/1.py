class Solution:
    def maxProduct(self, nums):
        l=len(nums)
        nums=sorted(nums,reverse=True)
        return (nums[0]-1)*(nums[1]-1)