import numpy as np


print(np.array(input().split(),int).reshape(3,3))
