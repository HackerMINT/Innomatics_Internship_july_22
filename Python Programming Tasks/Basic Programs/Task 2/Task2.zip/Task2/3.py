if __name__ == '__main__':
    L=[]
    for _ in range(int(input())):
        name = input()
        score = float(input())
        
        L.append([name,score])
    
    L.sort(key=lambda L:L[1])
    
    second_lowest=[]
    for i in range(len(L)):
        if L[i][1]!=L[0][1]:
            second_lowest.append(L[i][0])
            for j in range(i+1,len(L)):
                if L[j][1]==L[i][1]:
                    second_lowest.append(L[j][0])
                else:
                    break
            break        
        else:
            continue
           

    second_lowest.sort()
    for i in second_lowest:
        print(i)
