# Enter your code here. Read input from STDIN. Print output to STDOUT
tuple_len = int(input())
a = tuple(map(int, input().split(' ')))
t = hash(a)
print(t)
