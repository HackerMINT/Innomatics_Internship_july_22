N=int(input())
A=set()
for i in range(N):
    A.add(input())
print(len(A))